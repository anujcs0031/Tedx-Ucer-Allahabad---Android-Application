package com.tedxucer;

import android.content.Intent;
import android.content.res.Configuration;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {


    private WebView myWebView;
    Configuration newConfig;
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle state) {
        super.onRestoreInstanceState(state);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);





        //Full Screen Activity ---
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);




        setContentView(R.layout.activity_main);

        myWebView = (WebView)findViewById(R.id.webView);




        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
         myWebView.loadUrl("http://tedxucerallahabad.com");


        myWebView.setWebViewClient(new WebViewClient());


    }


    @Override
    public void onBackPressed() {


        if (myWebView.canGoBack()) {
            myWebView.goBack();
        } else {


            super.onBackPressed();
        }
    }
        public void onConfigurationChanged(Configuration newConfig)
        {
            super.onConfigurationChanged(newConfig);
            if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT)

            {
                //your code
            } else if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE)

            {
                //your code

            }
        }


    @Override
    public boolean onCreateOptionsMenu(android.view. Menu menu) {

        super.onCreateOptionsMenu(menu);

        MenuInflater blowup = getMenuInflater();
        blowup.inflate(R.menu.cool_menu,menu );

        return true;



    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){


            case   R.id.aboutUs:
                Intent i = new Intent("com.tedxucer.ABOUT");
                startActivity(i);


                break;

            case   R.id.volunteers:
                Intent j = new Intent("com.tedxucer.VOLUNTEERS");
                startActivity(j);


                break;
            case   R.id.contact:
                Intent k = new Intent("com.tedxucer.CONTACT");
                startActivity(k);


                break;



            case R.id.exit:

                finish();

                break;

        }

        return false;
    }





}
