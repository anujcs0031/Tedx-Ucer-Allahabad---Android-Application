package com.tedxucer;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.view.Window;
import android.view.WindowManager;

/**
 * Created by anujgupta on 02/07/17.
 */

public class Splash extends Activity {





    @Override
    protected void onCreate(@Nullable Bundle aa) {
        super.onCreate(aa);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.splash);



        Thread timer = new Thread(){

            public void run()
            {
                try
                {

                    sleep(3000);


                } catch(InterruptedException e ){

                    e.printStackTrace();

                } finally {

                    Intent openStartingPoint  = new Intent("com.tedxucer.Splash1");
                    startActivity(openStartingPoint);
                }
            }
        };  timer.start();

    }
    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }

}
