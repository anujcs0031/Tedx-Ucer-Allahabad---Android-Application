package com.tedxucer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.Window;
import android.view.WindowManager;


/**
 * Created by anujgupta on 17/07/17.
 */

public class Splash1 extends Activity {





    @Override
    protected void onCreate(@Nullable Bundle aa) {
        super.onCreate(aa);


        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.splash1);




        Thread timer = new Thread(){

            public void run()
            {
                try
                {

                    sleep(1500);


                } catch(InterruptedException e ){

                    e.printStackTrace();

                } finally {

                    Intent openStartingPoint  = new Intent("com.tedxucer.MainActivity");
                    startActivity(openStartingPoint);
                }
            }
        };  timer.start();

    }
    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }

}
